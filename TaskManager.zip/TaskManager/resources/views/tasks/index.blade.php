@extends('layouts.app')

@section('content')
    <label for="filter">Filter by Status:</label>
    <select name="filter" id="filter">
        <option value="all">All</option>
        <option value="in_progress">In Progress</option>
        <option value="completed">Completed</option>
    </select>

    <label for="sort">Sort by Title:</label>
    <select name="sort" id="sort">
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>

    <button id="apply-filters">Apply Filters</button>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach($tasks as $task)
                <tr>
                    <td>{{ $task->id }}</td>
                    <td>{{ $task->title }}</td>
                    <td>{{ $task->description }}</td>
                    <td>{{ $task->created_at }}</td>
                    <td>{{ $task->updated_at }}</td>
                    <td>
                        <form action="/tasks/{{ $task->id }}" method="post">
                            @csrf
                            @method('delete')
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <script>
        document.getElementById('apply-filters').addEventListener('click', function () {
            const filterValue = document.getElementById('filter').value;
            const sortValue = document.getElementById('sort').value;
            
            let url = '/tasks';
            
            if (filterValue !== 'all') {
                url += '?filter=' + filterValue;
            }
            
            if (sortValue !== 'asc') {
                url += (filterValue !== 'all' ? '&' : '?') + 'sort=' + sortValue;
            }
            
            window.location.href = url;
        });
    </script>
@endsection
