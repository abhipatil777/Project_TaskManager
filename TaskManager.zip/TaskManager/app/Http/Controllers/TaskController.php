<?php

namespace Database\Seeders;


use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{
    public function index(Request $request)
    {
        $query = Task::query();

        if ($request->has('filter')) {
            if ($request->filter == 'in_progress') {
                $query->whereNull('completed_at');
            } elseif ($request->filter == 'completed') {
                $query->whereNotNull('completed_at');
            }
        }

        if ($request->has('sort')) {
            $query->orderBy('title', $request->sort);
        }

        $tasks = $query->get();

        return view('tasks.index', compact('tasks'));
    }

    public function edit($id)
    {
        $task = Task::findOrFail($id);
        return view('tasks.edit', compact('task'));
    }

    public function update(Request $request, $id)
    {
        $task = Task::findOrFail($id);
        $validatedData = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable',
        ]);

        $task->update($validatedData);

        return redirect('/tasks');
    }

    public function destroy($id)
    {
        $task = Task::findOrFail($id);
        $task->delete();
        return redirect('/tasks');
    }
}
