
<form action="/tasks/{{ $task->id }}" method="post">
    @csrf
    @method('patch')
    <label for="title">Title:</label>
    <input type="text" name="title" id="title" value="{{ $task->title }}" required>
    <br>
    <label for="description">Description:</label>
    <textarea name="description" id="description">{{ $task->description }}</textarea>
    <br>
    <button type="submit">Update Task</button>
</form>
